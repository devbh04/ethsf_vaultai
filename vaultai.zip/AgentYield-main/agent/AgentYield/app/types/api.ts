export type AgentRequest = { userMessage: string };

export type AgentResponse = { response?: string; error?: string };
